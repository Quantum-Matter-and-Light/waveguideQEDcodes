%%

function [Xplot,Yplot,Gx,Gy,Gz,zeropos,AG0,AJ0]=Efieldplot(GFresult,mu,f,targetx,targety,delta_x,delta_y,oneD,twoD,dy)
cc=3e8;eps0=8.854e-12;
Efield=GFresult.E;
ffield=GFresult.f;
tmp=abs(ffield-f);
[idx idx]=min(tmp);
closest=ffield(idx);
w=2*pi*closest;
[idx1 idx1]=min(abs(GFresult.x-targetx));
[idx2 idx2]=min(abs(GFresult.y-targety));
zeropos=idx1*idx2;

[Xplot,Yplot]=meshgrid(GFresult.x,GFresult.y);
[Xsize, Ysize]=size(Xplot);
Gx=zeros(size(Xplot));
irun=0;

if twoD
    %% Photonic crystal structure (2D measurements: monitor-type "2D z-normal") %%
    for i1=1:Xsize
        for i2=1:Ysize
            irun=irun+1;
            Gx(i1,i2)=squeeze((Efield(irun,1,idx)))*cc^2*eps0/w^2/mu;          
        end
    end
    
    Gy=zeros(size(Xplot));
    irun=0;
    for i1=1:Xsize
        for i2=1:Ysize
            irun=irun+1;
            Gy(i1,i2)=squeeze((Efield(irun,2,idx)))*cc^2*eps0/w^2/mu;
        end
    end
    
    Gz=zeros(size(Xplot));
    irun=0;
    for i1=1:Xsize
        for i2=1:Ysize
            irun=irun+1;
            Gz(i1,i2)=squeeze((Efield(irun,3,idx)))*cc^2*eps0/w^2/mu;
        end
    end
    
    %% validation of unit cell averaged Green's function with analytical result %%
    
    Ex=zeros(size(Xplot));
    irun=0;
    for i1=1:Xsize
        for i2=1:Ysize
            irun=irun+1;
            Ex(i1,i2)=squeeze((Efield(irun,1,idx)));
        end
    end
    
    %Analytic formula
    xx=Xplot(1,:)'+delta_x;
    dxx=Xplot(1,2)-Xplot(1,1);
    kk=2*pi*f/cc;
    R=abs(xx-dxx/2)+1e-10;
    theta=(xx-dxx/2<0)*pi;
    Ext=mu/(4*pi*eps0).*exp(1i.*kk.*R)./R.*(kk.^2.*sin(theta).^2+(1./R.^2-1i.*kk./R).*(3*cos(theta).^2-1));
    V=dxx^3;
    [idx idx]=min(abs(xx-dxx/2));
    Ext(idx)=-mu/(3*eps0)/V+1i*imag(Ext(idx));
        
    AG0=imag(Ext)*cc^2*eps0/w^2/mu;
    AJ0=real(Ext)*cc^2*eps0/w^2/mu;
    
elseif oneD
    Gx=Efield(1,1,idx)*cc^2*eps0/w^2/mu;
    Gy=Efield(1,2,idx)*cc^2*eps0/w^2/mu;
    Gz=Efield(1,3,idx)*cc^2*eps0/w^2/mu;
    
    %Analytic formula
    xx=delta_x;
    dxx=dy;
    kk=2*pi*f/cc;
    R=abs(xx-dxx/2)+1e-10;
    theta=(xx-dxx/2<0)*pi;
    Ext=mu/(4*pi*eps0).*exp(1i.*kk.*R)./R.*(kk.^2.*sin(theta).^2+(1./R.^2-1i.*kk./R).*(3*cos(theta).^2-1));
    V=dxx^3;
    [idx idx]=min(abs(xx-dxx/2));
    Ext(idx)=-mu/(3*eps0)/V+1i*imag(Ext(idx));
    AG0=imag(Ext)*cc^2*eps0/w^2/mu;
    AJ0=real(Ext)*cc^2*eps0/w^2/mu;
end

