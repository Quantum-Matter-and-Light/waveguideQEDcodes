function [GammaJijNxx,GammaJij0xx,GammaJijNyy,GammaJij0yy,GammaJijNzz,GammaJij0zz,GammaJijNHxx,GammaJij0Hxx,GammaJijNHyy,GammaJij0Hyy,GammaJijNHzz,GammaJij0Hzz]=GammaJij_ver3(GN,G0)
%% Constants
clight=299792458;
mu0=4*pi*10^(-7);
ep0=8.85e-12;
hbar=1.05457148e-34;
h=2*pi*hbar;
fcs_d1=335.116*10^12;
fcs_d2=351.725*10^12; % Units in Hz
omega_d1=2*pi*fcs_d1;
omega_d2=2*pi*fcs_d2;
ec=1.6022*10^-19;
a0=5.291*10^-11;

%% full dipole moment matrix setup for D1 & D2 transition
I=7/2;
Li=0; %S
[Li,Ji,Fi,mfi]=spdf(Li);
Lf=1; %P
[Lf,Jf,Ff,mff]=spdf(Lf);
Fi=Fi{1}; % hyperfine ground states
Ffd1=Ff{1}; % hyperfine excited states for D1 transition
Ffd2=Ff{2}; % hyperfine excited states for D2 transition
mfig=mfi{1};
mff_d1=mff{1};
mff_d2=mff{2};
jj_factor=(2*Ji+1)/(2*Jf(2)+1);

%JdJD1=4.489*ec*a0; % Jonathan's thesis (A.19)
%JdJD2=6.324*ec*a0; % Jonathan's thesis (A.20)

Ff_eas=[Ff{1},Ff{2}];
Fi_easy=repmat(Fi',1,numel(Ff_eas));
Ff_easy=repmat(Ff_eas,numel(Fi),1);
Ji_easy=repmat([Ji;Ji],1,numel(Ff_eas));
Jf_easy=repmat([Jf(1)*ones(size(Ff{1})),Jf(2)*ones(size(Ff{2}))],numel(Jf),1);
FF=zeros(size(Ff_easy,1),size(Ff_easy,2));
omega_ff=zeros(size(FF));
alpha1_coeff=zeros(size(FF));
alpha2_coeff=zeros(size(FF));
q=[-1 0 1];
dipole_d1=cell(2,2);
dipole_d2=cell(2,4);

for ind_i=1:numel(Fi)
    for ind_f=1:numel(Ffd1)
        mfi1=mfig{ind_i};
        mffd1=mff_d1{ind_f};
        Hd1=zeros(numel(mfi1),numel(mffd1));
        for ii=1:3
            for mg=1:numel(mfi1)
                for me=1:numel(mffd1)               
                    [FdF(mg,me,ii)]=DipoleZeeman(0.5,0.5,Fi(ind_i),Ffd1(ind_f),mffd1(me),mfi1(mg),I,q(ii));
                    Hd1(mg,me,ii)=FdF(mg,me,ii);                    
                end
            end
        end
        dipole_d1_Zeeman{ind_i,ind_f}=Hd1;
    end
end

for ind_i=1:numel(Fi)
    for ind_f=1:numel(Ffd2)
        mfi1=mfig{ind_i};
        mffd2=mff_d2{ind_f};
        Hd2=zeros(numel(mfi1),numel(mffd2));
        for ii=1:3
            for mg=1:numel(mfi1)
                for me=1:numel(mffd2)                
                    [FdF(mg,me,ii)]=DipoleZeeman(0.5,1.5,Fi(ind_i),Ffd2(ind_f),mffd2(me),mfi1(mg),I,q(ii));
                    Hd2(mg,me,ii)=FdF(mg,me,ii);
                end
            end
        end
        dipole_d2_Zeeman{ind_i,ind_f}=Hd2;        
    end
end

%% Decay rates and Lamb shift calculation in Cartesian coordinate
GN=omega_d2/(6*pi*clight)*eye(3);
G0=omega_d2/(6*pi*clight)*eye(3);

for ind_i=1:numel(Fi)
    for ind_f=1:numel(Ffd2)
        temp=dipole_d2_Zeeman{ind_i,ind_f};
        D2dx=(1/sqrt(2))*(temp(:,:,1)-temp(:,:,3));
        D2dy=(1i/sqrt(2))*(temp(:,:,1)+temp(:,:,3));
        D2dz=temp(:,:,2);
        D2d=temp(:,:,1)+temp(:,:,2)+temp(:,:,3);
        D2ddx=conj(D2dx)';
        D2ddy=conj(-D2dy)';
        D2ddz=conj(D2dz)';
        D2Dxx{ind_i,ind_f}=D2ddx*D2dx;
        D2Dyy{ind_i,ind_f}=D2ddy*D2dy;
        D2Dzz{ind_i,ind_f}=D2ddz*D2dz;
        D2D{ind_i,ind_f}=D2d'*D2d;
        ex=[1 0 0];
        ey=[0 1 0];
        ez=[0 0 1];
        GammaJijNxx{ind_i,ind_f}=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*diag(D2Dxx{ind_i,ind_f}).*(ex*GN*ex');
        GammaJij0xx{ind_i,ind_f}=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*diag(D2Dxx{ind_i,ind_f}).*(ex*G0*ex');
        GammaJijNyy{ind_i,ind_f}=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*diag(D2Dyy{ind_i,ind_f}).*(ey*GN*ey');
        GammaJij0yy{ind_i,ind_f}=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*diag(D2Dyy{ind_i,ind_f}).*(ey*G0*ey');
        GammaJijNzz{ind_i,ind_f}=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*diag(D2Dzz{ind_i,ind_f}).*(ez*GN*ez');
        GammaJij0zz{ind_i,ind_f}=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*diag(D2Dzz{ind_i,ind_f}).*(ez*G0*ez');
        GammaJijNHxx(ind_i,ind_f)=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*trace(D2D{ind_i,ind_f}).*(ex*GN*ex');
        GammaJij0Hxx(ind_i,ind_f)=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*trace(D2D{ind_i,ind_f}).*(ex*G0*ex');
        GammaJijNHyy(ind_i,ind_f)=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*trace(D2D{ind_i,ind_f}).*(ey*GN*ey');
        GammaJij0Hyy(ind_i,ind_f)=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*trace(D2D{ind_i,ind_f}).*(ey*G0*ey');
        GammaJijNHzz(ind_i,ind_f)=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*trace(D2D{ind_i,ind_f}).*(ez*GN*ez');
        GammaJij0Hzz(ind_i,ind_f)=(2*omega_d2^2/(hbar*ep0*clight^2))*jj_factor*trace(D2D{ind_i,ind_f}).*(ez*G0*ez');
    end
end
TGJxx=sum(GammaJij0xx{1,1})+sum(GammaJij0xx{1,2})+sum(GammaJij0xx{1,3})+sum(GammaJij0xx{1,4})+ ...
     sum(GammaJij0xx{2,1})+sum(GammaJij0xx{2,2})+sum(GammaJij0xx{2,3})+sum(GammaJij0xx{2,4});
TGJyy=sum(GammaJij0xx{1,1})+sum(GammaJij0yy{1,2})+sum(GammaJij0yy{1,3})+sum(GammaJij0yy{1,4})+ ...
     sum(GammaJij0xx{2,1})+sum(GammaJij0yy{2,2})+sum(GammaJij0yy{2,3})+sum(GammaJij0yy{2,4});
TGJzz=sum(GammaJij0zz{1,1})+sum(GammaJij0zz{1,2})+sum(GammaJij0zz{1,3})+sum(GammaJij0zz{1,4})+ ...
     sum(GammaJij0zz{2,1})+sum(GammaJij0zz{2,2})+sum(GammaJij0zz{2,3})+sum(GammaJij0zz{2,4});

