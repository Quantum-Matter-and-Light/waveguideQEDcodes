function [Gamma,Jij]=GammaJij_ver4(GN)
%% Constants
clight=299792458;
mu0=4*pi*10^(-7);
ep0=8.85e-12;
hbar=1.05457148e-34;
h=2*pi*hbar;
fcs_d1=335.116*10^12;
fcs_d2=351.725*10^12; % Units in Hz
omega_d1=2*pi*fcs_d1;
omega_d2=2*pi*fcs_d2;
ec=1.6022*10^-19;
a0=5.291*10^-11;

%% Oscillator strength for D1 & D2 transition including Zeeman sublevels.
I=7/2;
Li=0; %S
[Li,Ji,Fi,mfi]=spdf(Li);
Lf=1; %P
[Lf,Jf,Ff,mff]=spdf(Lf);
Fi=Fi{1}; % hyperfine ground states
Ffd1=Ff{1}; % hyperfine excited states for D1 transition
Ffd2=Ff{2}; % hyperfine excited states for D2 transition
mfig=mfi{1};
mff_d1=mff{1};
mff_d2=mff{2};

%JdJD1=4.489*ec*a0; % Jonathan's thesis (A.19)
%JdJD2=6.324*ec*a0; % Jonathan's thesis (A.20)

Ff_eas=[Ff{1},Ff{2}];
Fi_easy=repmat(Fi',1,numel(Ff_eas));
Ff_easy=repmat(Ff_eas,numel(Fi),1);
Ji_easy=repmat([Ji;Ji],1,numel(Ff_eas));
Jf_easy=repmat([Jf(1)*ones(size(Ff{1})),Jf(2)*ones(size(Ff{2}))],numel(Jf),1);

pshalf=importdata('pshalf.mat');
omega_ps=(2*pi*clight)./(pshalf(1,[2 4])*1e-9);
tau_ps=pshalf(1,[3,5])*1e-6;
gamma_ps=1./tau_ps;
jj_factor=(2*Ji+1)./(2*Jf(2)+1);
jj_ps_sq=(3*pi*ep0*hbar*clight^3)./(omega_ps.^3).*(1./(jj_factor)).*gamma_ps;
Dm_d1=sqrt(jj_ps_sq(1,1));
Dm_d2=sqrt(jj_ps_sq(1,2));
q=[-1 0 1];

%% Oscillator strength
for ind_i=1:numel(Fi)
    for ind_f=1:numel(Ffd1)
        mfi1=mfig{ind_i};
        mffd1=mff_d1{ind_f};
        Hd1=zeros(numel(mfi1),numel(mffd1));
        HdH1=zeros(numel(mfi1),numel(mffd1));
        for ii=1:3
            for mg=1:numel(mfi1)
                for me=1:numel(mffd1)
                    [FdF(mg,me,ii)]=DipoleZeeman(0.5,0.5,Fi(ind_i),Ffd1(ind_f),mffd1(me),mfi1(mg),I,q(ii));
                    Hd1(mg,me,ii)=FdF(mg,me,ii);
                    HdH1(mg,me)=HdH1(mg,me)+FdF(mg,me,ii);
                    
                end
            end
        end
        dipole_d1_Zeeman{ind_i,ind_f}=Hd1;
        dipole_d1_hyperfine(ind_i,ind_f)=trace(HdH1'*HdH1)*(Dm_d1)^2;
    end
end

for ind_i=1:numel(Fi)
    for ind_f=1:numel(Ffd2)
        mfi1=mfig{ind_i};
        mffd2=mff_d2{ind_f};
        Hd2=zeros(numel(mfi1),numel(mffd2));
        HdH2=zeros(numel(mfi1),numel(mffd2));
        for ii=1:3
            for mg=1:numel(mfi1)
                for me=1:numel(mffd2)
                    [FdF(mg,me,ii)]=DipoleZeeman(0.5,1.5,Fi(ind_i),Ffd2(ind_f),mffd2(me),mfi1(mg),I,q(ii));
                    Hd2(mg,me,ii)=FdF(mg,me,ii);
                    HdH2(mg,me)=HdH2(mg,me)+FdF(mg,me,ii);
                    
                end
            end
        end
        dipole_d2_Zeeman{ind_i,ind_f}=Hd2;
        dipole_d2_hyperfine(ind_i,ind_f)=trace(HdH2'*HdH2)*(Dm_d2)^2;        
    end
end

%% Total Decay rate and Lamb shift for 5P3/2 state
% G=omega_d2/(6*pi*clight)*eye(3);
%  Gamma=sum(sum(dipole_d2_hyperfine))*(2*omega_d2^2/(hbar*ep0*clight^2))*(imag(G))*jj_factor;
%  Jij=sum(sum(dipole_d2_hyperfine))*(omega_d2^2/(hbar*ep0*clight^2))*(real(G))*jj_factor;

%% Decay rate and Lamb shift via Spherical decomposition and sum over all q,q'
% GN=1i*omega_d2/(6*pi*clight)*eye(3);
% G0=1i*omega_d2/(6*pi*clight)*eye(3);

GN00=(-1/sqrt(3))*trace(GN);
GN1p1=(1/2)*(GN(3,1)-GN(1,3)+1i*(GN(3,2)-GN(2,3)));
GN1m1=(1/2)*(GN(3,1)-GN(1,3)-1i*(GN(3,2)-GN(2,3)));
GN1z0=(1i/sqrt(2))*(GN(1,2)-GN(2,1));
GN2p2=(1/2)*(GN(1,1)-GN(2,2)+1i*(GN(1,2)+GN(2,1)));
GN2m2=(1/2)*(GN(1,1)-GN(2,2)-1i*(GN(1,2)+GN(2,1)));
GN2p1=(-1/2)*(GN(1,3)+GN(3,1)+1i*(GN(2,3)+GN(3,2)));
GN2m1=(1/2)*(GN(1,3)+GN(3,1)-1i*(GN(2,3)+GN(3,2)));
GN2z0=(1/sqrt(6))*(3*GN(3,3)-trace(GN));

for ind_i=1:numel(Fi)
    for ind_f=1:numel(Ffd2)
        temp=dipole_d2_Zeeman{ind_i,ind_f};
        dipGN_00=(-1/sqrt(3)).*(conj(temp(:,:,2))'*temp(:,:,2)+conj(temp(:,:,1))'*temp(:,:,1)+conj(temp(:,:,3))'*temp(:,:,3)).*GN00;
        dipGN_1z0=(1/sqrt(2)).*(conj(temp(:,:,3))'*temp(:,:,3)-conj(temp(:,:,1))'*temp(:,:,1)).*GN1z0.*(-1);
        dipGN_1p1=(-1/sqrt(2)).*(temp(:,:,2)'*conj(temp(:,:,3))+conj(temp(:,:,2))'*temp(:,:,3)).*GN1m1.*(-1);
        dipGN_1m1=(1/sqrt(2)).*(temp(:,:,2)'*conj(temp(:,:,1))+conj(temp(:,:,2))'*temp(:,:,1)).*GN1p1.*(-1);
        dipGN_2z0=(1/sqrt(6)).*(2*conj(temp(:,:,2))'*temp(:,:,2)-conj(temp(:,:,3))'*temp(:,:,3)-conj(temp(:,:,1))'*temp(:,:,1)).*GN2z0;
        dipGN_2p1=(-1/sqrt(2)).*(temp(:,:,2)'*conj(temp(:,:,3))-conj(temp(:,:,2))'*temp(:,:,3)).*GN2m1;
        dipGN_2m1=(-1/sqrt(2)).*(temp(:,:,2)'*conj(temp(:,:,1))-conj(temp(:,:,2))'*temp(:,:,1)).*GN2p1;
        dipGN_2p2=-1*temp(:,:,3)'*conj(temp(:,:,3)).*GN2m2;
        dipGN_2m2=-1*temp(:,:,1)'*conj(temp(:,:,1)).*GN2p2;
        dipGN=dipGN_00+dipGN_1z0+dipGN_1p1+dipGN_1m1+dipGN_2z0+dipGN_2p1+dipGN_2m1+dipGN_2p2+dipGN_2m2;
        GammaJijN{ind_i,ind_f}=dipGN.*(2*omega_d2^2/(hbar*ep0*clight^2))*(Dm_d2)^2*jj_factor;
        [Q,H]=eig(GammaJijN{ind_i,ind_f});
        GammaNFF{ind_i,ind_f}=sort(imag(diag(H)));
        JijNFF{ind_i,ind_f}=sort(real(diag(H)));
        GammaN(ind_i,ind_f)=sum(imag(diag(H)));
        JijN(ind_i,ind_f)=sum(real(diag(H)))/2;
    end
end
Gamma=sum(sum(GammaN))
Jij=sum(sum(JijN))

