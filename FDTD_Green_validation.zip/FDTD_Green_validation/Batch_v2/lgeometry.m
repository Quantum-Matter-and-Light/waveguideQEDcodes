function lgeometry(h,nSiN,tSiN,toggle)
%% Script to make the W1PCW structure
tSiN=200e-9;
wid=220e-9;
Ain=264e-9;
a0=373e-9;
thk=200e-9;
a0=373e-9;
ny=8;
r1=110e-9;
r2=110e-9;
r3=110e-9;
s1=-20e-9;
s2=-20e-9;
offset=120e-9;
Alpha=1.2;
NUnitCell=1;
ncell=1;
x0=a0/2;%-NUnitCell*ncell/2*a0+a0/4;
if toggle==1;
    for i1=1:NUnitCell
        W1PCWunitcell(h,true,nSiN,tSiN,ncell,x0,a0,wid,thk,ny,r1,r2,r3,s1,s2,offset,Alpha);
        x0=x0+a0*ncell;
    end
elseif toggle==2;
    lcommand(h,'selectpartial("W1PhCW_cell")',true);
    lcommand(h,'delete',true);
end
%% homogeneous
%planar(h,true,nSiN,tSiN)
%cylinder(h,true,nSiN,tSiN)
end

