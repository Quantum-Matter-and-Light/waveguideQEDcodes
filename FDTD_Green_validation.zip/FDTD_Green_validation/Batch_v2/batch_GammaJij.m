%% batch
close all
clear;
oneD=true;    %% monitor type (1D = point monitor // 2D = snap shot)
twoD=false;
prx=0.02e-6:0.02e-6:0.6e-6; %% positions of the point dipole sources
%prx=0:0.04e-6:0.2e-6; %% positions of the point dipole sources
pry=0;%:0.04e-6:0.12e-6;
for ii=1:length(prx)
    for jj=1:length(pry)
        for id=1:3
            cc=3e8; %speed of light
            %% Add Lumerical API to MATLAB
            CurrentFolder=pwd;
            path(path, 'C:\Program Files\Lumerical\FDTD\api\matlab')
            %appclose(h);
            h=appopen('fdtd');
            
            %% Load Lumerical Header API
            lheader(h,CurrentFolder)
            
            %% Structure parameters
            nSiO2= 1.45;
            nSiN = 1.997;
            tSiN = 200e-9;
            %Time/Freq Domain info
            fcs_d1=335.116e12;
            fcs_d2=351.726e12;
            
            %% Dipole source parameters
            freq = 351.0e12;
            bandwidth = 10e12;
            freqhighres = 500; %nPoints over the frequency span
            
            %% Simulation Parameters
            meshacc = 6;
            wSimVolx = 15.8e-6; %Simulation Volume : Squircle-W1 (80 unit cell)
            wSimVoly = 3.6e-6;
            wSimVolz = 0.3e-6;
%             wSimVolx = 15.8e-6; %Simulation Volume : APCW (80 unit cell)
%             wSimVoly = 0.7e-6;
%             wSimVolz = 0.3e-6;
            dx=40e-9;
            dy=dx;dz=dx;
            %        delta_x=dx/2;
            %        delta_y=dy/2;
            timefactor = 100.0;
            %100.0; %as in t = (time factor) * lZ / c
            
            xSimMin=-wSimVolx;
            xSimMax=wSimVolx;
            ySimMin=-wSimVoly;
            ySimMax=wSimVoly;
            zSimMax=wSimVolz;
            zSimMin=-wSimVolz;
            
            %% #For dipole rotations
            thid=[90,90,0];
            phid=[0,90,0];
            
            %% Dipole Source
            thetad=[90,90,0];
            phid=[0,90,0];
            
            %% Create the geometry
            toggle=1;
            lgeometry(h,nSiN,tSiN,toggle)
            
            if id==1
                dipoleaxis='x'
                DipoleSource(h,true,prx(ii)+dx/2,pry(jj),0,fcs_d2,100e12,thetad(id),phid(id),dipoleaxis);
            elseif id==2;
                dipoleaxis='y'
                DipoleSource(h,true,prx(ii),pry(jj)+dy/2,0,fcs_d2,100e12,thetad(id),phid(id),dipoleaxis);
            elseif id==3;
                dipoleaxis='z'
                DipoleSource(h,true,prx(ii),pry(jj),dz/2,fcs_d2,100e12,thetad(id),phid(id),dipoleaxis);
            end
            
            %% Setting FDTD simulation area
            Tf=timefactor*10e-6/cc;
            lFDTDcond(h,true,meshacc,Tf,xSimMin,xSimMax,ySimMin,ySimMax,zSimMin,zSimMax,dx,dy,dz);
            xpos=0;
            ypos=0;
            zpos=0;
            gap=250e-9;
            lFDTDmonitors(h,true,xSimMin,xSimMax,-gap/2,gap/2,zSimMin,zSimMax,xpos,ypos,zpos,prx(ii),pry(jj),freqhighres,oneD,twoD)
            lindex(h,true,xSimMin,xSimMax,ySimMin,ySimMax,zSimMin,zSimMax,0,0,0)
            
            lcommand(h,'save("lumerical-running-savefile")',true);
            lcommand(h,'run',true);
            lcommand(h,'GFresult=getresult("GreenFunctionDATA","E")',true);
            lcommand(h,'delta_x=getdata("GreenFunctionDATA","delta_x")',true);
            lcommand(h,'delta_y=getdata("GreenFunctionDATA","delta_y")',true);
            lcommand(h,'n = getresult("index_monitor","index")',true);
            lcommand(h,'mu = getdata("DSource","moment")',true);
            lcommand(h,['matlabsave("muresult' dipoleaxis '",mu)'],true);
            lcommand(h,['matlabsave("nresult' num2str(dipoleaxis) '",n)'],true);
            lcommand(h,['matlabsave("GFresult' num2str(dipoleaxis) '",GFresult)'],true);
            lcommand(h,['matlabsave("delta_x' num2str(dipoleaxis) '",delta_x)'],true);
            lcommand(h,['matlabsave("delta_y' num2str(dipoleaxis) '",delta_y)'],true);
            
            %% Analysis
            targetx=0;targety=0;
            nresult=load(['nresult' num2str(dipoleaxis) '.mat']);
            nresult=nresult.n;
            muresult=load(['muresult' dipoleaxis '.mat']);
            muresult=muresult.mu;
            delta_x=load(['delta_x' dipoleaxis '.mat']);
            delta_x=delta_x.delta_x;
            delta_y=load(['delta_y' dipoleaxis '.mat']);
            delta_y=delta_y.delta_y;
            GFresult=load(['GFresult' num2str(dipoleaxis) '.mat']);
            GFresult=GFresult.GFresult;
            [Xplot,Yplot,GxN,GyN,GzN,zeropos,AG0,AJ0]=Efieldplot(GFresult,muresult,fcs_d2,targetx,targety,delta_x,delta_y,oneD,twoD,dy);
            
            
            lcommand(h,'switchtolayout',true);
            toggle=2;
            lgeometry(h,1,tSiN,toggle)
            lcommand(h,'run',true);
            lcommand(h,'GFresult0=getresult("GreenFunctionDATA","E")',true);
            lcommand(h,['matlabsave("GFresult0' num2str(dipoleaxis) '",GFresult0)'],true);
            GFresult0=load(['GFresult0' num2str(dipoleaxis) '.mat']);
            GFresult0=GFresult0.GFresult0;
            [Xplot0,Yplot0,Gx0,Gy0,Gz0,zeropos,AG0,AJ0]=Efieldplot(GFresult0,muresult,fcs_d2,targetx,targety,delta_x,delta_y,oneD,twoD,dy);
            
            [ffield,GxNf,GyNf,GzNf]=Efieldfrequencyplot(GFresult,zeropos,muresult,oneD,twoD);
            [ffield,Gx0f,Gy0f,Gz0f]=Efieldfrequencyplot(GFresult0,zeropos,muresult,oneD,twoD);
            
            if oneD
                if id==1
                    GN(1,1,ii,jj)=GxN; GN(1,2,ii,jj)=GyN; GN(1,3,ii,jj)=conj(GzN);
                    G0(1,1,ii,jj)=Gx0; G0(1,2,ii,jj)=Gy0; G0(1,3,ii,jj)=conj(Gz0);
                    % G0(1,1,ii,jj)=AJ0+1i*AG0; G0(1,2,ii,jj)=0; G0(1,3,ii,jj)=0; % Analtyical solutions
                    
                    GNf(1,1,ii,jj,:)=GxNf; GNf(1,2,ii,jj,:)=GyNf; GNf(1,3,ii,jj,:)=conj(GzNf);
                    G0f(1,1,ii,jj,:)=Gx0f; G0f(1,2,ii,jj,:)=Gy0f; G0f(1,3,ii,jj,:)=conj(Gz0f);
                    
                elseif id==2
                    GN(2,1,ii,jj)=conj(GxN); GN(2,2,ii,jj)=GyN; GN(2,3,ii,jj)=conj(GzN);
                    G0(2,1,ii,jj)=conj(Gx0); G0(2,2,ii,jj)=Gy0; G0(2,3,ii,jj)=conj(Gz0);
                    % G0(2,1,ii,jj)=0; G0(2,2,ii,jj)=AJ0+1i*AG0; G0(2,3,ii,jj)=0;
                    
                    GNf(2,1,ii,jj,:)=conj(GxNf); GNf(2,2,ii,jj,:)=GyNf; GNf(2,3,ii,jj,:)=conj(GzNf);
                    G0f(2,1,ii,jj,:)=conj(Gx0f); G0f(2,2,ii,jj,:)=Gy0f; G0f(2,3,ii,jj,:)=conj(Gz0f);
                    
                elseif id==3
                    GN(3,1,ii,jj)=GxN; GN(3,2,ii,jj)=GyN; GN(3,3,ii,jj)=GzN;
                    G0(3,1,ii,jj)=Gx0; G0(3,2,ii,jj)=Gy0; G0(3,3,ii,jj)=Gz0;
                    % G0(3,1,ii,jj)=0; G0(3,2,ii,jj)=0; G0(3,3,ii,jj)=AJ0+1i*AG0;
                    
                    GNf(3,1,ii,jj,:)=GxNf; GNf(3,2,ii,jj,:)=GyNf; GNf(3,3,ii,jj,:)=GzNf;
                    G0f(3,1,ii,jj,:)=Gx0f; G0f(3,2,ii,jj,:)=Gy0f; G0f(3,3,ii,jj,:)=Gz0f;
                    
                end
                save('GreenN1D.mat','GN')
                save('Green01D.mat','G0')
                save('Greenf1D.mat','GNf')
                save('Greenf01D.mat','G0f')
                
            elseif twoD
                if id==1
                    GN(1,1,:,:)=GxN; GN(1,2,:,:)=GyN; GN(1,3,:,:)=conj(GzN);
                    G0(1,1,:,:)=Gx0; G0(1,2,:,:)=Gy0; G0(1,3,:,:)=conj(Gz0);
                    GNf(1,1,:)=GxNf; GNf(1,2,:)=GyNf; GNf(1,3,:)=conj(GzNf);
                    G0f(1,1,:)=Gx0f; G0f(1,2,:)=Gy0f; G0f(1,3,:)=conj(Gz0f);
                elseif id==2
                    GN(2,1,:,:)=conj(GxN); GN(2,2,:,:)=GyN; GN(2,3,:,:)=conj(GzN);
                    G0(2,1,:,:)=conj(Gx0); G0(2,2,:,:)=Gy0; G0(2,3,:,:)=conj(Gz0);
                    GNf(2,1,:)=conj(GxNf); GNf(2,2,:)=GyNf; GNf(2,3,:)=conj(GzNf);
                    G0f(2,1,:)=conj(Gx0f); G0f(2,2,:)=Gy0f; G0f(2,3,:)=conj(Gz0f);
                elseif id==3
                    GN(3,1,:,:)=GxN; GN(3,2,:,:)=GyN; GN(3,3,:,:)=GzN;
                    G0(3,1,:,:)=Gx0; G0(3,2,:,:)=Gy0; G0(3,3,:,:)=Gz0;
                    GNf(3,1,:)=GxNf; GNf(3,2,:)=GyNf; GNf(3,3,:)=GzNf;
                    G0f(3,1,:)=Gx0f; G0f(3,2,:)=Gy0f; G0f(3,3,:)=Gz0f;
                end
                save('GreenN2D.mat','GN')
                save('Green02D.mat','G0')
                save('Greenf2D.mat','GNf')
                save('Greenf02D.mat','G0f')
            end
            lcommand(h,'switchtolayout',true);
            appclose(h)
        end
    end
end
    %% Gamma1D // Jij %%
    if oneD
        for ii=1:length(prx)
            for jj=1:length(pry)
                D1=false;
                D2=true;
                [GammaJijN,GammaJij0]=GammaJij_ver2(GN(:,:,ii,jj),G0(:,:,ii,jj));
                GammaJijNxr(:,:,ii,jj)=GammaJijN;
                GammaJij0xr(:,:,ii,jj)=GammaJij0;
            end
        end
    elseif twoD
        for i=size(GN,3)
            for j=size(GN,4)
                [GammaJijN,GammaJij0]=GammaJij_ver2(GN(:,:,i,j),G0(:,:,i,j));
                GammaJijNxr(:,:,i,j)=GammaJijN;
                GammaJij0xr(:,:,i,j)=GammaJij0;
            end
        end
    end
    save('GammaJijN.mat','GammaJijNxr')
    save('GammaJij0.mat','GammaJij0xr')
    figplt(Xplot,Yplot,ffield,prx,pry,GN,G0,GNf,G0f,GammaJijNxr,GammaJij0xr,oneD,twoD)
    
    for ii=1:length(prx)
        [GammaJijNxx,GammaJij0xx,GammaJijNyy,GammaJij0yy,GammaJijNzz,GammaJij0zz,GammaJijNHxx,GammaJij0Hxx,GammaJijNHyy,GammaJij0Hyy,GammaJijNHzz,GammaJij0Hzz]=GammaJij_ver3(GN(:,:,ii),G0(:,:,ii));
        GammaJijNF45pxx=GammaJijNxx{2,4};
        GammaJij0F45pxx=GammaJij0xx{2,4};
        GammaJijNF45pyy=GammaJijNyy{2,4};
        GammaJij0F45pyy=GammaJij0yy{2,4};
        GammaJijNF45pzz=GammaJijNzz{2,4};
        GammaJij0F45pzz=GammaJij0zz{2,4};
        
        GammaNxxr(:,ii)=imag(GammaJijNF45pxx);
        Gamma0xxr(:,ii)=imag(GammaJij0F45pxx);
        JijNxxr(:,ii)=real(GammaJijNF45pxx)/2;
        Jij0xxr(:,ii)=real(GammaJij0F45pxx)/2;
        GammaNyyr(:,ii)=imag(GammaJijNF45pyy);
        Gamma0yyr(:,ii)=imag(GammaJij0F45pyy);
        JijNyyr(:,ii)=real(GammaJijNF45pyy)/2;
        Jij0yyr(:,ii)=real(GammaJij0F45pyy)/2;
        GammaNzzr(:,ii)=imag(GammaJijNF45pzz);
        Gamma0zzr(:,ii)=imag(GammaJij0F45pzz);
        JijNzzr(:,ii)=real(GammaJijNF45pzz)/2;
        Jij0zzr(:,ii)=real(GammaJij0F45pzz)/2;
        GammaJijNHx(ii)=sum(sum(GammaJijNHxx));
        GammaJij0Hx(ii)=sum(sum(GammaJij0Hxx));
        GammaJijNHy(ii)=sum(sum(GammaJijNHyy));
        GammaJij0Hy(ii)=sum(sum(GammaJij0Hyy));        
        GammaJijNHz(ii)=sum(sum(GammaJijNHzz));
        GammaJij0Hz(ii)=sum(sum(GammaJij0Hzz));    
    end
    
    figure(1)
    for i=1:11
        plot(prx,GammaNxxr(i,:))%./Gamma0xxr(i,:))
        xlabel('distance (m)')
        ylabel('Gamma_{total}/Gamma_{vac}')
        title('Decay rate_{xx} Fp=5 (planar structure)')
        hold on
    end
    hold off
    legend('m_{F}=+-5','m_{F}=+-4','m_{F}=+-3','m_{F}=+-2', ...
        'm_{F}=+-1','m_{F}=0')    
    print('decay_xx','-dpng')
    
    figure(2)
    for i=1:11
        plot(prx,GammaNyyr(i,:))%./Gamma0xxr(i,:))
        xlabel('distance (m)')
        ylabel('Gamma_{total}/Gamma_{vac}')
        title('Decay rate_{yy} Fp=5 (planar structure)')
        hold on
    end
    hold off
    legend('m_{F}=+-5','m_{F}=+-4','m_{F}=+-3','m_{F}=+-2', ...
        'm_{F}=+-1','m_{F}=0')    
    print('decay_yy','-dpng')
    
    figure(3)
    for i=1:11
        plot(prx,GammaNzzr(i,:))%./Gamma0xxr(i,:))
        xlabel('distance (m)')
        ylabel('Gamma_{total}/Gamma_{vac}')
        title('Decay rate_{zz} Fp=5 (planar structure)')
        hold on
    end
    hold off
    legend('m_{F}=+-5','m_{F}=+-4','m_{F}=+-3','m_{F}=+-2', ...
        'm_{F}=+-1','m_{F}=0')   
    print('decay_zz','-dpng')

    figure(4)
    for i=1:11
        plot(prx,(JijNxxr(i,:)-Jij0xxr(i,:))/(10^6))
        xlabel('distance (m)')
        xlim([0,300*10^-9])
        ylabel('Lamb shift_{xx} (MHz)')
        title('Lamb shift_{xx} Fp=5 (nanofiber structure)')
        hold on
    end
    hold off
    legend('m_{F}=+5','m_{F}=+4','m_{F}=+3','m_{F}=+2','m_{F}=+1','m_{F}=0','m_{F}=-1', ...
        'm_{F}=-2','m_{F}=-3','m_{F}=-4','m_{F}=-5')
    print('Lambshift_xx','-dpng')    
    
    figure(5)
    for i=1:11
        plot(prx,(JijNyyr(i,:)-Jij0yyr(i,:))/(10^6))
        xlabel('distance (m)')
        xlim([0,300*10^-9])
        ylabel('Lamb shift_{yy} (MHz)')
        title('Lamb shift_{yy} Fp=5 (nanofiber structure)')
        hold on
    end
    hold off
    legend('m_{F}=+5','m_{F}=+4','m_{F}=+3','m_{F}=+2','m_{F}=+1','m_{F}=0','m_{F}=-1', ...
        'm_{F}=-2','m_{F}=-3','m_{F}=-4','m_{F}=-5')
    print('Lambshift_yy','-dpng')
    
    figure(6)
    for i=1:11
        plot(prx,(JijNzzr(i,:)-Jij0zzr(i,:))/(10^6))
        xlabel('distance (m)')
        xlim([0,300*10^-9])
        ylabel('Lamb shift_{zz} (MHz)')
        title('Lamb shift_{zz} Fp=5 (nanofiber structure)')
        hold on
    end
    hold off
    legend('m_{F}=+5','m_{F}=+4','m_{F}=+3','m_{F}=+2','m_{F}=+1','m_{F}=0','m_{F}=-1', ...
        'm_{F}=-2','m_{F}=-3','m_{F}=-4','m_{F}=-5')
    print('Lambshift_zz','-dpng')
    
    figure(7)    
    plot(prx,imag(GammaJijNHx)/(10^6),'k-','linewidth',1.5)%./Gamma0xxr(i,:))
    xlabel('distance (m)')    
    ylabel('Gamma_{total xx} (MHz)') 
    title('Total decay rate of 5P3/2 state (planar structure)')
    print('decay_total_xx','-dpng')
    
    figure(8)
    plot(prx,(real(GammaJijNHx)-real(GammaJij0Hx))/(2*10^6),'k','linewidth',1.5)
    xlabel('distance (m)')
    xlim([0,300*10^-9])
    ylabel('Lamb shift_{xx} (MHz)')
    title('Lamb shift_{xx} of 5P3/2 state (planar structure)')
    print('Lambshift_total_xx','-dpng')
    
    figure(9)
    plot(prx,prx.^3.*(real(GammaJijNHx)-real(GammaJij0Hx))/(2*10^6),'k','linewidth',1.5)
    xlabel('distance (m)')
    ylabel('Lamb shift_{xx}*distance^3 (MHz*m^3)')
    title('C3 coefficent for 5P3/2 state (planar)')
    print('C3coeff5P3_2_xx','-dpng')
    
    figure(10)    
    plot(prx,imag(GammaJijNHy)/(10^6),'k-','linewidth',1.5)%./Gamma0xxr(i,:))
    xlabel('distance (m)')    
    ylabel('Gamma_{total yy} (MHz)') 
    title('Total decay rate of 5P3/2 state (planar structure)')
    print('decay_total_yy','-dpng')
    
    figure(11)
    plot(prx,(real(GammaJijNHy)-real(GammaJij0Hy))/(2*10^6),'k','linewidth',1.5)
    xlabel('distance (m)')
    xlim([0,300*10^-9])
    ylabel('Lamb shift_{yy} (MHz)')
    title('Lamb shift_{yy} of 5P3/2 state (planar structure)')
    print('Lambshift_total_yy','-dpng')
    
    figure(12)
    plot(prx,prx.^3.*(real(GammaJijNHy)-real(GammaJij0Hy))/(2*10^6),'k','linewidth',1.5)
    xlabel('distance (m)')
    ylabel('Lamb shift_{yy}*distance^3 (MHz*m^3)')
    title('C3 coefficent for 5P3/2 state (planar)')
    print('C3coeff5P3_2_yy','-dpng')
    
    figure(13)    
    plot(prx,imag(GammaJijNHz)/(10^6),'k-','linewidth',1.5)%./Gamma0xxr(i,:))
    xlabel('distance (m)')    
    ylabel('Gamma_{total zz} (MHz)') 
    title('Total decay rate of 5P3/2 state (planar structure)')
    print('decay_total_zz','-dpng')
    
    figure(14)
    plot(prx,(real(GammaJijNHz)-real(GammaJij0Hz))/(2*10^6),'k','linewidth',1.5)
    xlabel('distance (m)')
    xlim([0,300*10^-9])
    ylabel('Lamb shift_{zz} (MHz)')
    title('Lamb shift_{zz} of 5P3/2 state (planar structure)')
    print('Lambshift_total_zz','-dpng')
    
    figure(15)
    plot(prx,prx.^3.*(real(GammaJijNHz)-real(GammaJij0Hz))/(2*10^6),'k','linewidth',1.5)
    xlabel('distance (m)')
    ylabel('Lamb shift_{xx}*distance^3 (MHz*m^3)')
    title('C3 coefficent for 5P3/2 state (planar)')
    print('C3coeff5P3_2_zz','-dpng')
    