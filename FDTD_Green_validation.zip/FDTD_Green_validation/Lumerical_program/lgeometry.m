function lgeometry(h,nSiN,tSiN,dipoleaxis,dx,dy,dz,toggle)
%% Script to make the W1PCW structure
tSiN=200e-9;
wid=228e-9;
thk=200e-9;
a0=373e-9;
ny=8;
r1=110e-9;
r2=110e-9;
r3=110e-9;
s1=-20e-9;
s2=-20e-9;
offset=120e-9;
Alpha=1.15;
if dipoleaxis=='x'
    x0=a0/2+dx/2;
    y0=0;
    z0=0;
elseif dipoleaxis=='y'
    x0=a0/2;
    y0=dy/2;
    z0=0;
elseif dipoleaxis=='z'
    x0=a0/2;
    y0=0;
    z0=dz/2;
end

if toggle==1;
    W1PCWunitcell(h,true,nSiN,tSiN,x0,y0,z0,a0,wid,thk,ny,r1,r2,r3,s1,s2,offset,Alpha);
elseif toggle==2;
    lcommand(h,'selectpartial("W1PhCW_cell")',true);
    lcommand(h,'delete',true);
end
end

