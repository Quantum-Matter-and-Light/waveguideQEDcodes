%% batch 2017.09.20 revised by Youn 
close all
clear;
oneD=false;    %% monitor type (1D = point monitor // 2D = snap shot)
twoD=true;
initial=true;  %% ture: initial simulation // false: to continue from the last simulation
lastsimulation='simulation3';
thissimulation='simulation';
prx=0;%:0.04e-6:0.2e-6; %% positions of the point dipole sources
pry=0;%:0.04e-6:0.12e-6;
for ii=1:length(prx)
    for jj=1:length(pry)
        for id=1:3
            if id==2
                dipoleaxis='x'
            elseif id==1
                dipoleaxis='y'
            elseif id==3
                dipoleaxis='z'
            end            
            cc=299792458; %speed of light
            %% Add Lumerical API to MATLAB
            CurrentFolder=pwd;
            path(path, 'C:\Program Files\Lumerical\FDTD\api\matlab')
            %appclose(h);
            h=appopen('fdtd');           
            
            %% Load Lumerical Header API
            lheader(h,CurrentFolder)
            
            %% Structure parameters
            nSiO2= 1.45;
            nSiN = 1.997;
            tSiN = 200e-9;
            %Time/Freq Domain info
            fcs_d1=335.116e12;
            fcs_d2=351.726e12;
            a0=373e-9;
            %% Dipole source parameters
            freq = 351.726e12;
            bandwidth = 100e12;
            freqhighres = 8000; %nPoints over the frequency span
            
            %% Simulation Parameters
            meshacc = 6;
            wSimVolx = 8.4e-6; %Simulation Volume : Squircle-W1 (80 unit cell)
            wSimVoly = 4.0e-6;
            wSimVolz = 0.6e-6;
            dx=40e-9;
            dy=dx;dz=dx;
            timefactor = 10000;
            
            xSimMin=-wSimVolx;
            xSimMax=wSimVolx;
            ySimMin=-wSimVoly;
            ySimMax=wSimVoly;
            zSimMax=wSimVolz;
            zSimMin=-wSimVolz;
            
            %% #For dipole rotations
            thid=[90,90,0];
            phid=[90,0,0];
            
            %% Dipole Source
            thetad=[90,90,0];
            phid=[90,0,0];
            
            %% Create the geometry
            toggle=1;
            lgeometry(h,nSiN,tSiN,dipoleaxis,dx,dy,dz,toggle)
                                   
            if dipoleaxis=='x'
                if initial
                    DipoleSource(h,true,prx(ii)+dx/2,pry(jj),0,fcs_d2,bandwidth,thetad(id),phid(id),dipoleaxis);
                else
                    lcommand(h,['save("' thissimulation dipoleaxis '")'],true);
                    CollectLastSimdata(h,true,dipoleaxis,lastsimulation,thissimulation);
                    lcommand(h,'addimportedsource',true);
                    lset(h,true,'name','lastsimulation');
                    lcommand(h,'importdataset(EM)',true);
                end
            elseif dipoleaxis=='y'
                if initial
                    DipoleSource(h,true,prx(ii),pry(jj)+dy/2,0,fcs_d2,bandwidth,thetad(id),phid(id),dipoleaxis);
                else
                    lcommand(h,['save("' thissimulation dipoleaxis '")'],true);
                    CollectLastSimdata(h,true,dipoleaxis,lastsimulation,thissimulation);
                    lcommand(h,'addimportedsource',true);
                    lset(h,true,'name','lastsimulation');
                    lcommand(h,'importdataset(EM)',true);
                end
            elseif dipoleaxis=='z'                
                if initial
                    DipoleSource(h,true,prx(ii),pry(jj),dz/2,fcs_d2,bandwidth,thetad(id),phid(id),dipoleaxis);
                else
                    lcommand(h,['save("' thissimulation dipoleaxis '")'],true);
                    CollectLastSimdata(h,true,dipoleaxis,lastsimulation,thissimulation);
                    lcommand(h,'addimportedsource',true);
                    lset(h,true,'name','lastsimulation');
                    lcommand(h,'importdataset(EM)',true);
                end
            end
            
            %% Setting FDTD simulation area
            
            Tf=timefactor*10e-6/cc;
            lFDTDcond(h,true,meshacc,Tf,xSimMin,xSimMax,ySimMin,ySimMax,zSimMin,zSimMax,dx,dy,dz);
            %         lset(h,true,'x min bc','PML');
            %         lset(h,true,'x max bc','PML');
            %         lset(h,true,'y min bc','PML');
            %         lset(h,true,'y max bc','PML');
            %         lset(h,true,'z min bc','PML');
            %         lset(h,true,'z max bc','PML');
            %             if id==1;
            %                 lset(h,true,'x min bc','Anti-Symmetric')
            %                 lset(h,true,'y min bc','Symmetric')
            %                 lset(h,true,'z min bc','Symmetric')
            %             elseif id==2;
            %                 lset(h,true,'x min bc','Symmetric')
            %                 lset(h,true,'y min bc','Anti-Symmetric')
            %                 lset(h,true,'z min bc','Symmetric')
            %             elseif id==3;
            %                 lset(h,true,'x min bc','Symmetric')
            %                 lset(h,true,'y min bc','Symmetric')
            %                 lset(h,true,'z min bc','Anti-Symmetric')
            %             end
            xpos=0;
            ypos=0;
            zpos=0;            
            %         lFDTDmonitors(h,true,xSimMin/2,xSimMax/2,ySimMin/2,ySimMax/2,zSimMin,zSimMax,xpos,ypos,zpos,prx(ii),freqhighres,oneD,twoD)
            lFDTDmonitors(h,true,xSimMin,xSimMax,ySimMin,ySimMax,zSimMin,zSimMax,xpos,ypos,zpos,prx(ii),pry(jj),freqhighres,oneD,twoD)
            lindex(h,true,xSimMin,xSimMax,ySimMin,ySimMax,zSimMin,zSimMax,0,0,0)
            
            lcommand(h,['save("' thissimulation dipoleaxis '")'],true);
            lcommand(h,'run',true);
            lcommand(h,['save("' thissimulation dipoleaxis '")'],true);
            lcommand(h,'GFresult=getresult("GreenFunctionDATA","E")',true);
            lcommand(h,'delta_x=getdata("GreenFunctionDATA","delta_x")',true);
            lcommand(h,'delta_y=getdata("GreenFunctionDATA","delta_y")',true);
            lcommand(h,'n = getresult("index_monitor","index")',true);
            if initial
                lcommand(h,'mu = getdata("DSource","moment")',true);
                lcommand(h,['matlabsave("muresult' dipoleaxis '",mu)'],true);
            end
            lcommand(h,['matlabsave("nresult' num2str(dipoleaxis) '",n)'],true);
            lcommand(h,['matlabsave("GFresult' num2str(dipoleaxis) '",GFresult)'],true);
            lcommand(h,['matlabsave("delta_x' num2str(dipoleaxis) '",delta_x)'],true);
            lcommand(h,['matlabsave("delta_y' num2str(dipoleaxis) '",delta_y)'],true);
           
            %% Analysis
            targetx=0;targety=0;
            nresult=load(['nresult' num2str(dipoleaxis) '.mat']);
            nresult=nresult.n;
            muresult=load(['muresult' dipoleaxis '.mat']);
            muresult=muresult.mu;
            delta_x=load(['delta_x' dipoleaxis '.mat']);
            delta_x=delta_x.delta_x;
            delta_y=load(['delta_y' dipoleaxis '.mat']);
            delta_y=delta_y.delta_y;
            GFresult=load(['GFresult' num2str(dipoleaxis) '.mat']);
            GFresult=GFresult.GFresult;
            [Xplot,Yplot,GxN,GyN,GzN,zeropos,AG0,AJ0]=Efieldplot(GFresult,muresult,fcs_d2,targetx,targety,delta_x,delta_y,oneD,twoD,dy);
            [ffield,GxNf,GyNf,GzNf]=Efieldfrequencyplot(GFresult,zeropos,muresult,oneD,twoD);

            if oneD
                if dipoleaxis=='x'
                    GN(1,1,ii,jj)=GxN; GN(1,2,ii,jj)=GyN; GN(1,3,ii,jj)=conj(GzN);                  
                    GNf(1,1,ii,jj,:)=GxNf; GNf(1,2,ii,jj,:)=GyNf; GNf(1,3,ii,jj,:)=conj(GzNf);                    
                elseif dipoleaxis=='y'
                    GN(2,1,ii,jj)=conj(GxN); GN(2,2,ii,jj)=GyN; GN(2,3,ii,jj)=conj(GzN);                    
                    GNf(2,1,ii,jj,:)=conj(GxNf); GNf(2,2,ii,jj,:)=GyNf; GNf(2,3,ii,jj,:)=conj(GzNf);                    
                elseif dipoleaxis=='z'
                    GN(3,1,ii,jj)=GxN; GN(3,2,ii,jj)=GyN; GN(3,3,ii,jj)=GzN;                    
                    GNf(3,1,ii,jj,:)=GxNf; GNf(3,2,ii,jj,:)=GyNf; GNf(3,3,ii,jj,:)=GzNf;                    
                end
                save('GreenN1D.mat','GN')
                save('GreenNf1D.mat','GNf')
                
            elseif twoD
                if dipoleaxis=='x'
                    GN(1,1,:)=GxN; GN(1,2,:)=GyN; GN(1,3,:)=conj(GzN);
                    GNf(1,1,:)=GxNf; GNf(1,2,:)=GyNf; GNf(1,3,:)=conj(GzNf);
                elseif dipoleaxis=='y'
                    GN(2,1,:)=conj(GxN); GN(2,2,:)=GyN; GN(2,3,:)=conj(GzN);
                    GNf(2,1,:)=conj(GxNf); GNf(2,2,:)=GyNf; GNf(2,3,:)=conj(GzNf);
                elseif dipoleaxis=='z'
                    GN(3,1,:)=GxN; GN(3,2,:)=GyN; GN(3,3,:)=GzN;
                    GNf(3,1,:)=GxNf; GNf(3,2,:)=GyNf; GNf(3,3,:)=GzNf;
                end
                save('GreenN2D.mat','GN')
                save('GreenNf2D.mat','GNf')
            end
            lcommand(h,'switchtolayout',true);
            appclose(h)
        end
    end
end

%% Vacuum Green's function
Vac_timefactor=5;
[G0,G0f]=VacuumGF(oneD,twoD,wSimVolx,wSimVoly,wSimVolz,dx,freq,bandwidth,freqhighres,Vac_timefactor);

Greenfig(Xplot,Yplot,ffield,prx,pry,GN,G0,GNf,G0f,oneD,twoD)

VacGF=2*pi*ffield./(6*pi*cc);
figure(1)
h1=plot(ffield,squeeze(imag(G0f(1,1,:))),'r-','linewidth',1.5);
hold on
h2=plot(ffield,squeeze(imag(G0f(2,2,:))),'b--','linewidth',1.5);
h3=plot(ffield,squeeze(imag(G0f(3,3,:))),'k-','linewidth',1.5);
h4=plot(ffield,VacGF,'m--','linewidth',1);
hold off
xlabel('Frequency (Hz)','fontsize',14)
ylabel('Vacuum Green function','fontsize',14)
legend('G_{xx}','G_{yy}','G_{zz}','Theory (\omega/6\pic)','location','best','fontsize',12)
set(gca,'fontsize',12)
title(['X:' num2str(wSimVolx) ' Y:' num2str(wSimVoly) ' Z:' num2str(wSimVolz) ' T:' num2str(timefactor) ' dx:' num2str(dx)])
saveas(h1,['X' num2str(wSimVolx) ' Y' num2str(wSimVoly) ' Z' num2str(wSimVolz) ' T' num2str(timefactor) ' dx' num2str(dx) '.png'])
 
