function CollectLastSimdata(h,cont,dipoleaxis,lastsimulation,thissimulation)
lcommand(h,['load("' lastsimulation dipoleaxis '.fsp")'],cont);
lcommand(h,'E_field=getresult("GreenFunctionDATA","E")',cont);
lcommand(h,'H_field=getresult("GreenFunctionDATA","H")',cont);
lcommand(h,'ffield=getresult("GreenFunctionDATA","f")',cont);
lcommand(h,'mu = getdata("DSource","moment")',true);
lcommand(h,['matlabsave("muresult' dipoleaxis '",mu)'],true);
lcommand(h,'EM = rectilineardataset("EM fields",E_field.x,E_field.y,E_field.z)',cont);
lcommand(h,'EM.addparameter("lambda",c/ffield,"f",ffield)',cont)
lcommand(h,'EM.addattribute("E",E_field.Ex,E_field.Ey,E_field.Ez)',cont);
lcommand(h,'EM.addattribute("H",H_field.Hx,H_field.Hy,H_field.Hz)',cont);
lcommand(h,['load("' thissimulation dipoleaxis '")'],cont);
end
