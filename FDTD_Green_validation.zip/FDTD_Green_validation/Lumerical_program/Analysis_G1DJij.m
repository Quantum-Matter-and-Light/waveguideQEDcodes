for id=1:3
    cc=3e8; %speed of light
    %% Recall the simulation setup
    dx=40e-9;
    dy=dx;dz=dx;
    oneD=false;
    twoD=true;
    if id==1
        dipoleaxis='x'
    elseif id==2;
        dipoleaxis='y'
    elseif id==3;
        dipoleaxis='z'
    end
    
    %% load datas
    targetx=0;targety=0;
    nresult=load(['nresult' num2str(dipoleaxis) '.mat']);
    nresult=nresult.n;
    muresult=load(['muresult' dipoleaxis '.mat']);
    muresult=muresult.mu;
    delta_x=load(['delta_x' dipoleaxis '.mat']);
    delta_x=delta_x.delta_x;
    delta_y=load(['delta_y' dipoleaxis '.mat']);
    delta_y=delta_y.delta_y;
    GFresult=load(['GFresult' num2str(dipoleaxis) '.mat']);
    GFresult=GFresult.GFresult;
    GFresult0=load(['GFresult0' num2str(dipoleaxis) '.mat']);
    GFresult0=GFresult0.GFresult0;
    
    %% Total decay rates and Lamb shifts in frequency domain
    [idx1 idx1]=min(abs(GFresult.x-targetx));
    [idx2 idx2]=min(abs(GFresult.y-targety));
    zeropos=idx1*idx2;
    
    [ffield,GxNf,GyNf,GzNf]=Efieldfrequencyplot(GFresult,zeropos,muresult,oneD,twoD);
    [ffield,Gx0f,Gy0f,Gz0f]=Efieldfrequencyplot(GFresult0,zeropos,muresult,oneD,twoD);
    
    if id==1
        GNf(1,1,:)=GxNf; GNf(1,2,:)=GyNf; GNf(1,3,:)=conj(GzNf);
        G0f(1,1,:)=Gx0f; G0f(1,2,:)=Gy0f; G0f(1,3,:)=conj(Gz0f);
    elseif id==2
        GNf(2,1,:)=conj(GxNf); GNf(2,2,:)=GyNf; GNf(2,3,:)=conj(GzNf);
        G0f(2,1,:)=conj(Gx0f); G0f(2,2,:)=Gy0f; G0f(2,3,:)=conj(Gz0f);
    elseif id==3
        GNf(3,1,:)=GxNf; GNf(3,2,:)=GyNf; GNf(3,3,:)=GzNf;
        G0f(3,1,:)=Gx0f; G0f(3,2,:)=Gy0f; G0f(3,3,:)=Gz0f;
    end
    save('Greenf2D.mat','GNf')
    save('Greenf02D.mat','G0f')
end

[GammaN,JijN]=GammaJij_ver4(squeeze(GNf));
[Gamma0,Jij0]=GammaJij_ver4(squeeze(G0f));

figure(1)
h=plot(ffield,squeeze(GammaN(2,2,:)./Gamma0(2,2,:)));
hTitle  = title (['Decay rate$_{yy}$'],'Interpreter','latex');
hXLabel = xlabel('frequency (Hz)','Interpreter','latex');
hYLabel = ylabel('$$Gamma_{total}/Gamma_{vac}$$','Interpreter','latex');
set(h,'Color',[0 0 0],'LineWidth',1.5 );
xlim([3.2*10^14,3.8*10^14])
saveas(h,['Gamma_yy.png'])

figure(2)
h1=plot(ffield,squeeze(JijN(2,2,:)-Jij0(2,2,:))./(2*pi));
hTitle = title(['Lambshift$_{yy}$'],'Interpreter','latex');
hXLabel = xlabel('frequency (Hz)','Interpreter','latex');
hYLabel = ylabel(['Lambshift$_{yy}$ (Hz)'],'Interpreter','latex');
set(h1,'Color',[0 0 0],'LineWidth',1.5 );
xlim([3.2*10^14,3.8*10^14])
saveas(h,['Jii_yy.png'])


[MX IX]=max(squeeze(imag(GNf(2,2,:))))
[MN IN]=min(squeeze(imag(GNf(2,2,:))))

figure(3)
h2=semilogy(ffield*10^(-12),squeeze(GammaN(2,2,:)-MN));
hold on
h3=semilogy(ffield*10^(-12),abs(squeeze(JijN(2,2,:)-Jij0(2,2,:))./(2*pi)));
hold off
hTitle  = title (['Decay rate$_{yy}$ and Lamb shift$_{yy}$'],'Interpreter','latex');
hXLabel = xlabel('frequency (THz)','Interpreter','latex');
hYLabel = ylabel(['$$\Gamma_{1D}$$  J$$_{1D}$$ (Hz)'],'Interpreter','latex');
set(h2,'Color',[0 0 0],'LineWidth',1.5 );
set(h3,'Color',[1 0 0],'LineWidth',1.5 );
legend(['\Gamma_{1D}'],['J_{1D}'],'location','best','Interpreter','latex')
xlim([346.5,347.5])
set(gca,'XTick',[346.5:0.2:347.5])
saveas(h2,['Gamma1D_yy.png'])

figure(4)
h3=semilogy(ffield*10^(-12),abs(squeeze(GammaN(2,2,:)-MN)./(squeeze(JijN(2,2,:)-Jij0(2,2,:))./(2*pi))));
hTitle  = title (['$$\vert{\Gamma_{1D}/J_{1D}}\vert$$'],'Fontsize',14,'Interpreter','latex');
hXLabel = xlabel('frequency (THz)','Interpreter','latex');
hYLabel = ylabel(['$$\vert{\Gamma_{1D}/J_{1D}}\vert$$'],'Fontsize',14,'Interpreter','latex');
set(h3,'Color',[0 0 0],'LineWidth',1.5 );
xlim([346.5,347.5])
set(gca,'XTick',[346.5:0.2:347.5])
saveas(h3,['Gamma1DJij_yy.png'])

figure(5)
h4=semilogy(ffield*10^(-12),abs((squeeze(JijN(2,2,:)-Jij0(2,2,:))./(2*pi))./squeeze(GammaN(2,2,:)-MN)));
hTitle  = title (['$$\vert{J_{1D}/\Gamma_{1D}}\vert$$'],'Fontsize',14,'Interpreter','latex');
hXLabel = xlabel('frequency (THz)','Interpreter','latex');
hYLabel = ylabel(['$$\vert{J_{1D}/\Gamma_{1D}}\vert$$'],'Fontsize',14,'Interpreter','latex');
set(h4,'Color',[0 0 0],'LineWidth',1.5 );
set(gca,'XTick',[346.5:0.2:347.5])
xlim([346.5,347.5])
saveas(h4,['JijGamma1D_yy.png'])


for id=1:3
    if id==1
        dipoleaxis='x'
    elseif id==2;
        dipoleaxis='y'
    elseif id==3;
        dipoleaxis='z'
    end
    
    targetx=0;targety=0;
    nresult=load(['nresult' num2str(dipoleaxis) '.mat']);
    nresult=nresult.n;
    muresult=load(['muresult' dipoleaxis '.mat']);
    muresult=muresult.mu;
    delta_x=load(['delta_x' dipoleaxis '.mat']);
    delta_x=delta_x.delta_x;
    delta_y=load(['delta_y' dipoleaxis '.mat']);
    delta_y=delta_y.delta_y;
    GFresult=load(['GFresult' num2str(dipoleaxis) '.mat']);
    GFresult=GFresult.GFresult;
    GFresult0=load(['GFresult0' num2str(dipoleaxis) '.mat']);
    GFresult0=GFresult0.GFresult0;
    
    [Xplot,Yplot,GxN,GyN,GzN,zeropos,AG0,AJ0]=Efieldplot(GFresult,muresult,ffield(IX),targetx,targety,delta_x,delta_y,oneD,twoD,dy);
    [Xplot0,Yplot0,Gx0,Gy0,Gz0,zeropos,AG0,AJ0]=Efieldplot(GFresult0,muresult,ffield(IX),targetx,targety,delta_x,delta_y,oneD,twoD,dy);
    
    if id==1
        GN(1,1,:)=squeeze(GxN); GN(1,2,:)=squeeze(GyN); GN(1,3,:)=squeeze(conj(GzN));
        G0(1,1,:)=squeeze(Gx0); G0(1,2,:)=squeeze(Gy0); G0(1,3,:)=squeeze(conj(Gz0));
        
    elseif id==2
        GN(2,1,:)=squeeze(conj(GxN)); GN(2,2,:)=squeeze(GyN); GN(2,3,:,:)=squeeze(conj(GzN));
        G0(2,1,:)=squeeze(conj(Gx0)); G0(2,2,:)=squeeze(Gy0); G0(2,3,:,:)=squeeze(conj(Gz0));
        
    elseif id==3
        GN(3,1,:)=squeeze(GxN); GN(3,2,:)=squeeze(GyN); GN(3,3,:)=squeeze(GzN);
        G0(3,1,:)=squeeze(Gx0); G0(3,2,:)=squeeze(Gy0); G0(3,3,:)=squeeze(Gz0);
        
    end
end
save('GreenN2D.mat','GN')
save('Green02D.mat','G0')
save('Greenf2D.mat','GNf')
save('Greenf02D.mat','G0f')

[GammaNx,JijNx]=GammaJij_ver4(squeeze(GN));
[Gamma0x,Jij0x]=GammaJij_ver4(squeeze(G0));

figure(5)
h4=plot(Xplot,squeeze(GammaNx(2,2,:)));
hTitle  = title (['Total Decay rate$_{yy}$'],'Fontsize',15,'Interpreter','latex');
hXLabel = xlabel('x (m)','Fontsize',15,'Interpreter','latex');
hYLabel = ylabel('$$\Gamma_{yy}$$ (Hz)','Fontsize',15,'Interpreter','latex');
set(h4,'Color',[0 0 0],'LineWidth',1.5 );
saveas(h4,['Gamma_yyr.png'])

figure(6)
h5=plot(Xplot,squeeze(JijNx(2,2,:)-Jij0x(2,2,:)));
hTitle  = title (['Coherent coupling rate$_{yy}$'],'Fontsize',15,'Interpreter','latex');
hXLabel = xlabel('x (m)','Fontsize',15,'Interpreter','latex');
hYLabel = ylabel(['$$Jij_{yy}$$ (Hz)'],'Fontsize',15,'Interpreter','latex');
set(h5,'Color',[0 0 0],'LineWidth',1.5 );
saveas(h5,['Jij_yyr.png'])
