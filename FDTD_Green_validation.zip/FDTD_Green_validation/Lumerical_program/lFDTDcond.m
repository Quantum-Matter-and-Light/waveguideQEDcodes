%%
function lFDTDcond(h,cont,meshacc,Tf,xSimMin,xSimMax,ySimMin,ySimMax,zSimMin,zSimMax,dx,dy,dz)
lcommand(h,'addfdtd',cont)
%lset(h,cont,'dimension',1)  % 1 = 2D, 2= 3D
lset(h,cont,'mesh accuracy',meshacc);
lset(h,cont,'simulation time',Tf);
lset(h,cont,'x min',xSimMin);lset(h,cont,'x max',xSimMax);
lset(h,cont,'y min',ySimMin);lset(h,cont,'y max',ySimMax);
lset(h,cont,'z min',zSimMin);lset(h,cont,'z max',zSimMax);
lset(h,cont,'auto shutoff min',1e-40);
lset(h,cont,'mesh type','uniform');
lset(h,cont,'min mesh step',2.5e-10);
lset(h,cont,'define x mesh by','max mesh step');lset(h,cont,'define y mesh by','max mesh step');lset(h,cont,'define z mesh by','max mesh step');
lset(h,cont,'dx',dx);
lset(h,cont,'dy',dy);
lset(h,cont,'dz',dz);

end
