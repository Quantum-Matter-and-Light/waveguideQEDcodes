%%
function lFDTDmonitors(h,cont,xSimMin,xSimMax,ySimMin,ySimMax,zSimMin,zSimMax,xpos,ypos,zpos,prx,pry,freqhighres,oneD,twoD)

lcommand(h,'addpower',cont)
lset(h,cont,'name','GreenFunctionDATA');
if twoD
    lset(h,cont,'monitor type','linear x');
    %    lset(h,cont,'monitor type','2D Z-normal');
    lset(h,cont,'x min',xSimMin);lset(h,cont,'x max',xSimMax);
    %    lset(h,cont,'y min',ySimMin);lset(h,cont,'y max',ySimMax);
    lset(h,cont,'y',ypos);
    lset(h,cont,'z',zpos);
elseif oneD
    lset(h,cont,'monitor type','point');
    lset(h,cont,'x',prx);
    lset(h,cont,'y',pry);
    lset(h,cont,'z',zpos);
end
lset(h,cont,'override global monitor settings',1);
lset(h,cont,'frequency points',freqhighres);
lset(h,cont,'spatial interpolation','none');

end